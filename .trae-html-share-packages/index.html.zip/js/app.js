/* ============================================================
   语界 · 应用逻辑  v2.1.0
   本地账号 · 不背单词式词卡 · SRS 间隔复习 · 澎湃美学 UI
   🔊 发音: 三层回退 (安卓原生TTS桥 → 在线CDN音频+IndexedDB缓存 → speechSynthesis)
   ✨ 体验: 左右滑动翻卡 / 长按发音 / 自动朗读 / 首页一键继续
   ============================================================ */
'use strict';

/* ---------- 工具 ---------- */
const $  = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const shuffle = a => { a=[...a]; for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; };
const dateKey = (offset=0) => { const d=new Date(); d.setDate(d.getDate()+offset); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
const today = () => dateKey(0);
const GREET = h => h<5?'夜深了':h<9?'早上好':h<12?'上午好':h<14?'中午好':h<18?'下午好':h<22?'晚上好':'夜深了';
const AVATARS = ['🐻','🐱','🦊','🐼','🐰','🐸','🦁','🐯','🐨','🦉','🐳','🦋'];
const COLORS  = ['#FF6A3D','#00B578','#2E6BFF','#FA5151','#A855F7','#8A6BE0','#00A8C6','#C13A54','#B8860B'];
const colorOf = s => COLORS[[...s].reduce((x,c)=>x+c.charCodeAt(0),0)%COLORS.length];
const delay = ms => new Promise(r => setTimeout(r, ms));

/* 词义归一化: 兼容英语富格式与日韩简格式 */
function normWord(lessonId, raw){
  if(Array.isArray(raw[4] && raw[4][0])){
    return { w:raw[0], ph:raw[1], def:raw[2], root:raw[3],
      ex:(raw[4]||[]).map(e=>({t:e[0], m:e[1], tag:e[2]||''})) };
  }
  return { w:raw[0], ph:raw[1], def:raw[2], root:'', ex:[{t:raw[3], m:raw[4], tag:''}] };
}
function lessonWords(lessonId){
  const c = CONTENT[lessonId];
  return c && c.words ? c.words.map(w => normWord(lessonId, w)) : [];
}

/* ---------- 本地数据库 ---------- */
const LS_KEY = 'yujie_v3';
let DB = (() => {
  try{ const d = JSON.parse(localStorage.getItem(LS_KEY)); if(d && d.users) return d; }catch(e){}
  return { users:[], session:null, prefs:{autoSpeak:true, theme:'hyper', accent:'orange'} };
})();
if(!DB.prefs) DB.prefs = {autoSpeak:true, theme:'hyper', accent:'orange'};
const save = () => localStorage.setItem(LS_KEY, JSON.stringify(DB));
let U = DB.users.find(u => u.id === DB.session) || null;

function newUser(name, avatar, lang, level, goal){
  return {
    id:'u'+Date.now().toString(36), name, avatar, color:colorOf(name),
    createdAt:Date.now(), lang, level, dailyGoal:goal, ttsRate:1,
    xp:0,
    streak:{count:0, last:'', days:{}},
    log:{},
    stats:{decks:0,words:0,reviews:0,grammar:0,listen:0,speak:0},
    srs:{},
    lessons:{},
    badges:[],
  };
}
const levelOf   = (l,lv) => LANGUAGES[l].levels.find(x=>x.id===lv);
const userLevel = () => levelOf(U.lang, U.level);

/* ---------- Toast / 彩带 / 触感 ---------- */
function toast(msg, icon='✨'){
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<span class="toast-ic">${icon}</span><span>${esc(msg)}</span>`;
  $('#toasts').appendChild(t);
  setTimeout(()=>{ t.classList.add('out'); setTimeout(()=>t.remove(),320); }, 2200);
}
function confetti(){
  const colors=['#FF6A3D','#2E6BFF','#00B578','#FA5151','#A855F7','#FFB800'];
  for(let i=0;i<70;i++){
    const c=document.createElement('div');
    c.className='confetti';
    c.style.cssText=`left:${Math.random()*100}%;background:${colors[i%colors.length]};animation-delay:${Math.random()*.6}s;animation-duration:${2+Math.random()*1.4}s;transform:rotate(${Math.random()*360}deg);width:${6+Math.random()*6}px;height:${10+Math.random()*10}px;border-radius:2px;`;
    document.body.appendChild(c);
    setTimeout(()=>c.remove(), 4200);
  }
}
function haptic(strength='light'){
  if(!navigator.vibrate) return;
  if(strength==='heavy') navigator.vibrate([20,30,20]);
  else if(strength==='medium') navigator.vibrate(15);
  else navigator.vibrate(5);
}

/* ============================================================
   🔊 语音 · 三层回退方案
   优先级: ① 安卓 NativeTTS JSBridge
          ② 在线词典 CDN mp3 (有道/dict.cn) + IndexedDB 缓存 → 音频元素播放
          ③ 浏览器 speechSynthesis
   ============================================================ */
const AUD = {
  idb: null,
  dbReady: false,
  netMode: true, // 联网模式, 启动时检测 navigator.onLine
  ttsNative: false,
  audioEl: null,
  cacheName: 'yujie-audio-v1',
  /** 有道 US 发音 URL (type=2=美音, type=1=英音) */
  cdnUrl(word, type='us'){
    const w = encodeURIComponent(word);
    // 多 CDN fallback, 由 fetch 逐个尝试
    const hosts = [
      `https://dict.youdao.com/dictvoice?audio=${w}&type=${type==='us'?2:1}`,
      `https://shared.youdao.com/dict/market/audio/dict/${type==='us'?'us':'uk'}/${encodeURIComponent(w[0]||'a')}/${w}.mp3`,
      `https://cdn.dict.cn/audio/${encodeURIComponent(w)}.mp3`,
    ];
    return hosts;
  },
  /** IndexedDB 打开 */
  async openDB(){
    if(this.dbReady) return this.idb;
    return new Promise((res, rej)=>{
      try{
        const req = indexedDB.open('yujie_audio', 1);
        req.onupgradeneeded = e => {
          const db = e.target.result;
          if(!db.objectStoreNames.contains('blobs')) db.createObjectStore('blobs', {keyPath:'k'});
        };
        req.onsuccess = e => { this.idb = e.target.result; this.dbReady = true; res(this.idb); };
        req.onerror = e => rej(e);
      }catch(e){ rej(e); }
    });
  },
  async blobGet(k){
    await this.openDB();
    return new Promise(res=>{
      try{
        const tx = this.idb.transaction('blobs','readonly');
        const r = tx.objectStore('blobs').get(k);
        r.onsuccess = () => res(r.result ? r.result.b : null);
        r.onerror = () => res(null);
      }catch(e){ res(null); }
    });
  },
  async blobPut(k, blob){
    try{
      await this.openDB();
      const tx = this.idb.transaction('blobs','readwrite');
      tx.objectStore('blobs').put({k, b:blob});
    }catch(e){}
  },
  async fetchCdn(urls){
    for(const url of urls){
      try{
        const r = await fetch(url, {method:'GET', mode:'cors', credentials:'omit', cache:'force-cache'});
        if(r.ok && r.status < 400){
          const blob = await r.blob();
          if(blob.size > 200) return {blob, url};
        }
      }catch(e){}
    }
    return null;
  },
  /** 播放一次 mp3 Blob */
  playBlob(blob, rate=1){
    return new Promise((res, rej)=>{
      try{
        if(!this.audioEl) this.audioEl = new Audio();
        const a = this.audioEl;
        if(a.paused === false){ try{a.pause();}catch(e){} }
        a.src = URL.createObjectURL(blob);
        a.playbackRate = rate;
        a.onended = () => { try{URL.revokeObjectURL(a.src);}catch(e){} res(true); };
        a.onerror = () => { try{URL.revokeObjectURL(a.src);}catch(e){} rej(false); };
        const p = a.play();
        if(p && p.catch) p.catch(()=>rej(false));
      }catch(e){ rej(false); }
    });
  },
  speakBrowser(text, langId, rate){
    return new Promise(res=>{
      try{
        if(!('speechSynthesis' in window)) { res(false); return; }
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = LANGUAGES[langId].ttsLang;
        u.rate = rate;
        u.pitch = 1;
        u.volume = 1;
        // 优先选高质量发音引擎
        const voices = speechSynthesis.getVoices && speechSynthesis.getVoices();
        if(voices && voices.length){
          const pref = voices.find(v=>v.lang===u.lang && /Google|Microsoft|Samantha/i.test(v.name)) ||
                       voices.find(v=>v.lang===u.lang) || voices[0];
          if(pref) u.voice = pref;
        }
        u.onend = ()=>res(true);
        u.onerror = ()=>res(false);
        speechSynthesis.speak(u);
        // 兜底超时 (部分设备 never trigger onend)
        setTimeout(()=>res(false), 10000);
      }catch(e){ res(false); }
    });
  }
};

/* ---------- 公共 speak() 入口 ---------- */
let _speaking = false;
async function speak(text, langId, rate, opts={}){
  if(!text) return;
  rate = rate || (U && U.ttsRate) || 1;
  if(_speaking){ try{ window.NativeTTS && window.NativeTTS.stop(); if(window.AUD && AUD.audioEl) AUD.audioEl.pause(); if('speechSynthesis' in window) speechSynthesis.cancel(); }catch(e){} }
  _speaking = true;
  let ok = false;
  const source = opts.source || 'word';
  try {
    // ① 安卓 WebView 原生 TTS (秒级响应,零流量)
    if(window.NativeTTS && (AUD.ttsNative || opts.forceNative)){
      try{ window.NativeTTS.speak(text, LANGUAGES[langId].ttsLang, rate); ok = true; }catch(e){ ok=false; }
    }

    // ② 英语单词 → 有道 CDN mp3 + IndexedDB (有网时音质最佳,离线也能放已缓存)
    if(!ok && source==='word' && (langId==='en')){
      const key = 'en::' + text.toLowerCase().trim();
      let blob = await AUD.blobGet(key);
      if(!blob && AUD.netMode){
        const r = await AUD.fetchCdn(AUD.cdnUrl(text, U && U.accent==='british'?'uk':'us'));
        if(r){ blob = r.blob; await AUD.blobPut(key, blob); }
      }
      if(blob){ try{ ok = await AUD.playBlob(blob, rate); }catch(e){ ok=false; } }
    }

    // ③ 兜底: Web Speech API
    if(!ok){ ok = await AUD.speakBrowser(text, langId, rate); }
  }catch(e){ ok=false; }
  finally {
    setTimeout(()=>{ _speaking = false; }, ok? 200 : 400);
  }
  return ok;
}

/* NativeTTS 就绪回调 */
window.__ttsReady = function(ok){
  AUD.ttsNative = !!ok;
  if(ok) toast('系统TTS引擎已就绪','🔊');
};

/* 网络状态监听 (自动切换在线/离线) */
window.addEventListener('online',  ()=>{ AUD.netMode = true;  toast('已联网 · CDN发音就绪','🌐'); }, {passive:true});
window.addEventListener('offline', ()=>{ AUD.netMode = false; toast('离线模式 · 使用系统发音','📴'); }, {passive:true});
AUD.netMode = navigator.onLine !== false;
/* voice 预加载 (部分浏览器要手动触发) */
try{ if('speechSynthesis' in window){ speechSynthesis.getVoices(); speechSynthesis.onvoiceschanged = ()=>speechSynthesis.getVoices(); } }catch(e){}
try{ AUD.openDB().catch(()=>{}); }catch(e){}

/* ---------- 导航 ---------- */
let tab = 'home';
let courseView = null;
let ob = null;
let courseLangTab = null;

function go(t){ tab = t; courseView = null; render(); }
function openCourse(l, lv){ courseView = {lang:l, level:lv}; render(); }

/* ---------- 渲染入口 ---------- */
function render(){
  if(!U){ renderOnboard(); return; }
  if(!courseLangTab) courseLangTab = U.lang;
  const tb = $('#tabbar');
  if(tb) tb.hidden = false;
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const app = $('#app');
  if(courseView){ app.innerHTML = renderCourseDetail(); }
  else if(tab === 'home')    app.innerHTML = renderHome();
  else if(tab === 'courses') app.innerHTML = renderCourses();
  else if(tab === 'review')  app.innerHTML = renderReview();
  else if(tab === 'me')      app.innerHTML = renderMe();
  app.scrollTop = 0;
  bindCommon();
  // 全局动画: 首屏缓入
  const page = app.firstElementChild;
  if(page){ page.classList.add('fade-slide-in'); }
}

function bindCommon(){
  $$('.tab').forEach(b => {
    b.onclick = () => { haptic('light'); go(b.dataset.tab); };
  });
  // 词卡区域左右滑动 (通用绑定)
  bindSwipe();
}

/* ============================================================
   引导 · 创建本地账号 (三步简化版 · 澎湃美学 大卡片)
   ============================================================ */
function startOnboard(){
  ob = { step:1, name:'', avatar:AVATARS[Math.floor(Math.random()*AVATARS.length)],
         lang:'en', level:'cet4', goal:20 };
  renderOnboard();
}
function renderOnboard(){
  $('#tabbar').hidden = true;
  const el = $('#app');
  const total = 3;
  const stepBar = Array.from({length:total},(_,i)=>`<span class="step-dot ${i<ob.step?'on':''} ${i===ob.step-1?'cur':''}"></span>`).join('');

  let html = `<div class="onboard hyper">
    <div class="ob-head">
      <div class="ob-logo-card"><span class="ob-logo">🌏</span></div>
      <div class="stepbar">${stepBar}</div>
    </div>`;

  if(ob.step === 1){
    html += `
    <div class="ob-hero">
      <h1 class="display">推开语言的大门<span class="accent">.</span></h1>
      <p class="subtle">四六级 · 日语 · 韩语 · 不背单词式学习 · 数据全在本机</p>
    </div>
    <div class="ob-form card card-xl">
      <div class="field">
        <label class="label">怎么称呼你?</label>
        <input id="obName" class="input" placeholder="昵称 (1-12字)" maxlength="12" value="${esc(ob.name)}">
      </div>
      <div class="field">
        <label class="label">挑个头像</label>
        <div class="avatar-pick">
          ${AVATARS.map(a=>`<button class="avatar-opt ${a===ob.avatar?'on':''}" data-a="${a}">${a}</button>`).join('')}
        </div>
      </div>
      <button class="btn btn-primary btn-xl" id="obNext">下一步 →</button>
    </div>`;
  }
  else if(ob.step === 2){
    html += `
    <div class="ob-hero">
      <h1 class="display">选一门语言<span class="accent">，</span>一起出发</h1>
      <p class="subtle">词书和等级可以随时切换</p>
    </div>
    <div class="lang-list">
      ${Object.values(LANGUAGES).map(l=>`
        <button class="lang-card ${ob.lang===l.id?'on':''}" data-l="${l.id}">
          <div class="lc-flag">${l.flag}</div>
          <div class="lc-body">
            <div class="lc-name">${l.name}<span class="lc-native">${l.native}</span></div>
            <div class="lc-count">${l.levels.length} 个等级 · 适配 SRS 复习</div>
          </div>
          <div class="lc-check">${ob.lang===l.id?'✓':''}</div>
        </button>`).join('')}
    </div>
    <div class="ob-form">
      <label class="label" style="display:block;margin:18px 0 10px;">当前语言等级</label>
      <div class="pill-row">
        ${LANGUAGES[ob.lang].levels.map(lv=>`
          <button class="pill ${ob.level===lv.id?'on':''}" data-lv="${lv.id}">${lv.name}</button>`).join('')}
      </div>
      <div class="row-btns">
        <button class="btn btn-ghost btn-lg" id="obBack">← 上一步</button>
        <button class="btn btn-primary btn-lg" id="obNext">下一步 →</button>
      </div>
    </div>`;
  }
  else{
    const goals = [
      {n:10, tag:'轻松入门',  desc:'每天 10 个新词 + 复习'},
      {n:20, tag:'日常打卡',  desc:'推荐给备考四级的同学'},
      {n:30, tag:'进阶训练',  desc:'六级冲刺推荐 30+'},
      {n:40, tag:'学霸模式',  desc:'高强度备考 / 突击'},
    ];
    html += `
    <div class="ob-hero">
      <h1 class="display">定个小目标<span class="accent">✨</span></h1>
      <p class="subtle">每天学习 + 复习的单词总量,以后可以改</p>
    </div>
    <div class="goal-grid">
      ${goals.map(g=>`
        <button class="goal-card ${ob.goal===g.n?'on':''}" data-g="${g.n}">
          <div class="g-tag">${g.tag}</div>
          <div class="g-num">${g.n}</div>
          <div class="g-desc">${g.desc}</div>
        </button>`).join('')}
    </div>
    <div class="row-btns" style="margin-top:22px">
      <button class="btn btn-ghost btn-lg" id="obBack">← 上一步</button>
      <button class="btn btn-primary btn-lg" id="obDone">开始学习 🚀</button>
    </div>`;
  }

  html += `</div>`;
  el.innerHTML = html;

  // 绑定
  if(ob.step===1){
    const input = $('#obName'); input.focus();
    $$('.avatar-opt').forEach(b => b.onclick = () => {
      ob.name = input.value.trim();
      ob.avatar = b.dataset.a; haptic('light'); renderOnboard();
    });
    $('#obNext').onclick = () => {
      const n = input.value.trim();
      if(!n){ toast('先给自己起个名字吧','✏️'); input.focus(); return; }
      ob.name = n; ob.step = 2; haptic('medium'); renderOnboard();
    };
  }
  else if(ob.step===2){
    $$('.lang-card').forEach(b => b.onclick = () => {
      ob.lang = b.dataset.l; ob.level = LANGUAGES[ob.lang].levels[0].id; haptic('light'); renderOnboard();
    });
    $$('.pill[data-lv]').forEach(b => b.onclick = () => { ob.level = b.dataset.lv; haptic('light'); renderOnboard(); });
    $('#obBack').onclick = () => { ob.step = 1; renderOnboard(); };
    $('#obNext').onclick = () => { ob.step = 3; haptic('medium'); renderOnboard(); };
  }
  else{
    $$('.goal-card').forEach(b => b.onclick = () => { ob.goal = +b.dataset.g; haptic('light'); renderOnboard(); });
    $('#obBack').onclick = () => { ob.step = 2; renderOnboard(); };
    $('#obDone').onclick = () => {
      U = newUser(ob.name, ob.avatar, ob.lang, ob.level, ob.goal);
      DB.users.push(U); DB.session = U.id; save();
      ob = null; tab = 'home'; render();
      confetti(); haptic('heavy'); toast('欢迎加入语界,一起加油!','🎉');
    };
  }
}

/* ============================================================
   首页 (澎湃美学 - 卡片堆叠 + 悬浮大按钮)
   ============================================================ */
function todayLog(){ return U.log[today()] || {words:0,review:0,xp:0}; }

function renderHome(){
  const h = new Date().getHours();
  const lg = todayLog();
  const done = Math.min(lg.words + lg.review, U.dailyGoal);
  const pct = Math.round(done / U.dailyGoal * 100);
  const due = dueWords().length;
  const lv = userLevel();
  const quote = DAILY_QUOTES[new Date().getDate() % DAILY_QUOTES.length];
  const level = Math.floor(U.xp / 200) + 1;
  const lvlXp = U.xp - (level-1)*200;
  const lvlPct = Math.min(100, Math.round(lvlXp/200*100));
  const nxt = nextLesson();
  const badgeCount = (U.badges||[]).length;

  // 继续学习卡
  let cc;
  if(due > 0){
    cc = `<div class="cc-card" onclick="go('review')">
      <div class="cc-ic 🔄"></div>
      <div class="cc-body">
        <span class="cc-tag">🔄 到期复习</span>
        <div class="cc-title">${due} 个单词在等你</div>
        <div class="cc-desc">SRS Box 到期,先复习再开启新课</div>
      </div>
      <div class="cc-cta">Go</div>
    </div>`;
  } else if(nxt){
    const tm = TYPE_META[nxt.type];
    cc = `<div class="cc-card" onclick="openLesson('${U.lang}','${U.level}','${nxt.id}')">
      <div class="cc-ic ${tm.icon}"></div>
      <div class="cc-body">
        <span class="cc-tag">${tm.name} · ${esc(lv.name)}</span>
        <div class="cc-title">${esc(nxt.title)}</div>
        <div class="cc-desc">继续上次的学习旅程 · XP +${nxt.xp}</div>
      </div>
      <div class="cc-cta">开始</div>
    </div>`;
  } else {
    cc = `<div class="cc-card" onclick="go('courses')">
      <div class="cc-ic 🎉"></div>
      <div class="cc-body">
        <span class="cc-tag">恭喜完成</span>
        <div class="cc-title">${esc(lv.name)} 全部通关</div>
        <div class="cc-desc">去词书看看其它等级或语言 →</div>
      </div>
      <div class="cc-cta">词书</div>
    </div>`;
  }

  return `
  <div class="home-view">
    <!-- 顶部渐变 Header -->
    <header class="home-header">
      <div class="hh-row">
        <div class="hi">
          <div class="hi-avatar">${U.avatar}</div>
          <div class="hi-text">
            <div class="hi-hi">${GREET(h)}，<b>${esc(U.name)}</b> 👋</div>
            <div class="hi-sub">${esc(LANGUAGES[U.lang].name)} · ${esc(lv.name)}</div>
          </div>
        </div>
        <div class="hi-rank">
          <div class="lv-badge">Lv.${level}</div>
          <div class="st-streak">🔥 ${U.streak.count||0}</div>
        </div>
      </div>

      <!-- 环形日目标进度 -->
      <div class="goal-ring-card">
        <div class="ring-wrap">
          <svg viewBox="0 0 120 120" class="ring">
            <defs>
              <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#FF6A3D"/>
                <stop offset="55%" stop-color="#FF9F40"/>
                <stop offset="100%" stop-color="#FFD166"/>
              </linearGradient>
            </defs>
            <circle cx="60" cy="60" r="52" stroke="rgba(0,0,0,0.05)" stroke-width="12" fill="none"/>
            <circle cx="60" cy="60" r="52" stroke="url(#g1)" stroke-width="12" fill="none"
              stroke-linecap="round"
              stroke-dasharray="${2*Math.PI*52}"
              stroke-dashoffset="${2*Math.PI*52*(1 - pct/100)}"
              transform="rotate(-90 60 60)"/>
          </svg>
          <div class="ring-center">
            <div class="ring-num">${done}<span class="small">/${U.dailyGoal}</span></div>
            <div class="ring-txt">今日目标 ${pct}%</div>
          </div>
        </div>
        <div class="goal-stats">
          <div class="gs"><b>${lg.words||0}</b><span>新学</span></div>
          <div class="gs"><b>${lg.review||0}</b><span>复习</span></div>
          <div class="gs"><b>+${lg.xp||0}</b><span>XP</span></div>
        </div>
      </div>
    </header>

    <!-- 一键继续 大卡片 -->
    ${cc}

    <!-- 二级双栏: 连续打卡 + 成就数 + 已掌握词数 -->
    <section class="grid-2">
      <div class="stat-card onyx">
        <div class="sc-ic">🔥</div>
        <div class="sc-val">${U.streak.count||0}</div>
        <div class="sc-lb">连续学习 天</div>
      </div>
      <div class="stat-card mint">
        <div class="sc-ic">🏅</div>
        <div class="sc-val">${badgeCount}</div>
        <div class="sc-lb">解锁成就 枚</div>
      </div>
    </section>

    <!-- 下节课列表 (最多3个) -->
    <section class="section">
      <div class="sec-title"><h3>📚 今日推荐</h3><a class="more" onclick="go('courses')">更多 →</a></div>
      <div class="rec-list">
        ${recommendNextLessons().map(l=>{
          const t=TYPE_META[l.type];
          return `<button class="rec-card" onclick="openLesson('${U.lang}','${U.level}','${l.id}')">
            <span class="rc-ic ${t.cls}">${t.icon}</span>
            <div class="rc-body">
              <div class="rc-name">${esc(l.title)}</div>
              <div class="rc-meta">${t.name} · XP +${l.xp}</div>
            </div>
            <span class="rc-arrow">›</span>
          </button>`;
        }).join('') || emptyTile('暂无推荐，去词书看看吧')}
      </div>
    </section>

    <!-- 成就展示 (前3) -->
    <section class="section">
      <div class="sec-title"><h3>🏆 我的成就</h3><a class="more" onclick="go('me')">全部 →</a></div>
      <div class="badge-row">
        ${ACHIEVEMENTS.slice(0, 6).map(a=>{
          const got = U.badges.includes(a.id);
          const [cur, tot] = typeof a.prog === 'function' ? a.prog(U) : [0,1];
          return `<div class="badge-card ${got?'on':''}">
            <div class="b-ic">${a.icon}</div>
            <div class="b-name">${esc(a.name)}</div>
            <div class="b-prog">
              <div class="b-bar"><i style="width:${Math.min(100,Math.round(cur/tot*100))}%"></i></div>
              <span>${cur}/${tot}</span>
            </div>
          </div>`;
        }).join('')}
      </div>
    </section>

    <!-- 每日一句 -->
    <section class="section">
      <div class="daily-quote">
        <div class="dq-en">"${esc(quote.en)}"</div>
        <div class="dq-cn">— ${esc(quote.cn)}</div>
        <button class="dq-speak" onclick="speak(${JSON.stringify(quote.en)},'en',1,{source:'word'})">🔊</button>
      </div>
    </section>

    <!-- 等级进度条 -->
    <section class="section">
      <div class="lvl-card">
        <div class="lv-head"><span>等级进度</span><span class="xp">XP ${U.xp}</span></div>
        <div class="lvl-row">
          <span>Lv.${level}</span>
          <div class="lvl-bar"><i style="width:${lvlPct}%"></i></div>
          <span>Lv.${level+1}</span>
        </div>
        <div class="lv-sub">再获得 ${200 - lvlXp} XP 升级</div>
      </div>
    </section>

    <div style="height:24px"></div>
  </div>`;
}

function emptyTile(msg){
  return `<div class="empty-card">
    <div class="empty-ic">📭</div>
    <div class="empty-txt">${esc(msg)}</div>
  </div>`;
}

function recommendNextLessons(){
  const ls = COURSES[U.lang] && COURSES[U.lang][U.level];
  if(!ls) return [];
  const rec = [];
  for(const u of ls){
    for(const l of u.lessons){
      if(!U.lessons[l.id] || !U.lessons[l.id].done) rec.push(l);
      if(rec.length >= 3) return rec;
    }
  }
  return rec;
}

function nextLesson(){
  const ls = COURSES[U.lang] && COURSES[U.lang][U.level];
  if(!ls) return null;
  for(const u of ls) for(const l of u.lessons)
    if(!U.lessons[l.id] || !U.lessons[l.id].done) return l;
  return null;
}

/* ============================================================
   词书 Tab
   ============================================================ */
function renderCourses(){
  const langs = Object.values(LANGUAGES);
  return `
  <div class="page">
    <div class="page-head">
      <h1 class="page-title">词书</h1>
      <p class="page-sub">选择语言和等级,开启 SRS 记忆之旅</p>
      <div class="pill-row">
        ${langs.map(l=>`
          <button class="pill ${courseLangTab===l.id?'on':''}" data-lang="${l.id}">
            ${l.flag} ${l.name}
          </button>`).join('')}
      </div>
    </div>
    <div class="level-grid">
      ${LANGUAGES[courseLangTab].levels.map(lv=>{
        const units = (COURSES[courseLangTab][lv.id]||[]);
        const totalLessons = units.reduce((n,u)=>n+u.lessons.length,0);
        const doneLessons = units.reduce((n,u)=>n+u.lessons.filter(l=>U.lessons[l.id] && U.lessons[l.id].done).length,0);
        const pct = totalLessons ? Math.round(doneLessons/totalLessons*100) : 0;
        return `<button class="level-card" onclick="openCourse('${courseLangTab}','${lv.id}')">
          <div class="lv-tag ${courseLangTab}">${LANGUAGES[courseLangTab].flag}</div>
          <div class="lv-card-body">
            <h3>${esc(lv.name)}</h3>
            <p>${esc(lv.desc)}</p>
            <div class="progress">
              <div class="pbar"><i style="width:${pct}%"></i></div>
              <span>${doneLessons}/${totalLessons} · ${pct}%</span>
            </div>
          </div>
        </button>`;
      }).join('')}
    </div>
  </div>`;
}

function bindCourses(){
  $$('.pill[data-lang]').forEach(b=>b.onclick=()=>{
    courseLangTab = b.dataset.lang; render();
  });
}

/* ============================================================
   词书详情
   ============================================================ */
function renderCourseDetail(){
  const {lang, level} = courseView;
  const lv = levelOf(lang, level);
  const units = COURSES[lang][level] || [];
  return `
  <div class="page">
    <div class="page-head compact">
      <button class="back-btn" onclick="backToLevels()">←</button>
      <div>
        <h1 class="page-title">${esc(lv.name)}</h1>
        <p class="page-sub">${LANGUAGES[lang].flag} ${LANGUAGES[lang].name} · ${esc(lv.desc)}</p>
      </div>
    </div>
    <div class="unit-list">
      ${units.map((u,i)=>{
        const all = u.lessons.length;
        const dn = u.lessons.filter(l => U.lessons[l.id] && U.lessons[l.id].done).length;
        const pct = Math.round(dn/all*100);
        return `<section class="unit-card">
          <div class="unit-head">
            <div class="unit-index">UNIT ${String(i+1).padStart(2,'0')}</div>
            <div class="unit-body">
              <h3>${esc(u.title)}</h3>
              <p>${esc(u.desc)}</p>
            </div>
            <div class="unit-pill">${dn}/${all}</div>
          </div>
          <div class="progress unit-prog"><div class="pbar"><i style="width:${pct}%"></i></div></div>
          <div class="lesson-list">
            ${u.lessons.map(l=>{
              const t=TYPE_META[l.type];
              const done = U.lessons[l.id] && U.lessons[l.id].done;
              const score = done && U.lessons[l.id].score;
              return `<button class="lesson-card ${done?'done':''}" onclick="openLesson('${lang}','${level}','${l.id}')">
                <span class="lc-ic ${t.cls}">${t.icon}</span>
                <div class="lc-body">
                  <div class="lc-name">${esc(l.title)}</div>
                  <div class="lc-meta">${t.name} · XP +${l.xp}${done?` · ★${score}`:''}</div>
                </div>
                <span class="lc-check">${done?'✓':'→'}</span>
              </button>`;
            }).join('')}
          </div>
        </section>`;
      }).join('')}
    </div>
  </div>`;
}
function backToLevels(){ courseView = null; tab='courses'; render(); }

/* ============================================================
   复习 Tab
   ============================================================ */
function dueWords(){
  const t = today();
  const due = [];
  const langLevels = LANGUAGES[U.lang].levels.map(l=>l.id);
  for(const ll of langLevels){
    const units = COURSES[U.lang][ll]||[];
    for(const u of units){
      for(const l of u.lessons){
        const words = lessonWords(l.id);
        for(const w of words){
          const s = (U.srs[l.id]||{})[w.w];
          if(!s || !s.seen){
            due.push({lesson:l.id, w, due:null}); // 新词也在复习里算吗? 实际上新词优先去词汇课
          } else if(s.due <= t){
            due.push({lesson:l.id, w, due:s.due});
          }
        }
      }
    }
  }
  return due;
}
function renderReview(){
  const list = dueWords();
  const today = list.length;
  return `
  <div class="page">
    <div class="page-head">
      <h1 class="page-title">复习</h1>
      <p class="page-sub">SRS 间隔到期 · 记得牢才是真学会</p>
    </div>

    <div class="review-hero">
      <div class="rh-left">
        <div class="rh-num">${today}</div>
        <div class="rh-txt">${today>0?'今天待复习':'今天没有到期词🎉'}</div>
      </div>
      <div class="rh-right">
        <div class="rh-ic">🔁</div>
      </div>
    </div>

    ${today>0? `
    <div class="srs-boxes">
      ${[1,2,4,7,15,30].map((d,i)=>{
        const count = list.filter(x=>x.w && U.srs && (U.srs[x.lesson]&&U.srs[x.lesson][x.w]||{}).box===i+1).length;
        return `<div class="srs-box">
          <span class="sb-day">${d}天</span>
          <span class="sb-n">${count}</span>
        </div>`;
      }).join('')}
      <div class="srs-box"><span class="sb-day">新词</span><span class="sb-n">${list.filter(x=>!(x.w && U.srs && (U.srs[x.lesson]||{})[x.w])).length}</span></div>
    </div>
    <button class="btn btn-primary btn-xl wide" onclick="startReview()">🎯 开始复习 (${today})</button>` : emptyTile('先学完一组单词,明后天它们会出现在这里~')}

    <section class="section" style="margin-top:22px">
      <div class="sec-title"><h3>🧠 SRS Box 系统</h3></div>
      <div class="srs-info">
        <div class="srs-line">认识 → 进入下一个 Box · 不认识 → 退一格并稍后重现</div>
        <div class="srs-line">Box 间隔: 1天 → 2天 → 4天 → 7天 → 15天 → 30天(掌握)</div>
      </div>
    </section>
  </div>`;
}

/* ============================================================
   我的 Tab
   ============================================================ */
function renderMe(){
  const level = Math.floor(U.xp/200)+1;
  const lvlXp = U.xp-(level-1)*200;
  const s = U.stats;
  const total = s.words + s.reviews + s.grammar + s.listen + s.speak;
  const langsDone = {};
  for(const lk in U.lessons) if(U.lessons[lk].done){ const lid=lk.split('-')[1]; langsDone[lid]=(langsDone[lid]||0)+1; }
  return `
  <div class="page">
    <header class="me-hero">
      <div class="me-row">
        <div class="me-avatar">${U.avatar}</div>
        <div class="me-info">
          <div class="me-name">${esc(U.name)} <span class="me-lv">Lv.${level}</span></div>
          <div class="me-sub">${LANGUAGES[U.lang].flag} ${LANGUAGES[U.lang].name} · ${userLevel().name}</div>
          <div class="me-xpbar"><i style="width:${Math.min(100, lvlXp/2)}%"></i><span>XP ${U.xp}</span></div>
        </div>
        <button class="me-menu" onclick="toggleUserMenu(event)">⋯</button>
      </div>

      <div class="stats-grid">
        <div class="sg"><b>${s.words||0}</b><span>新学单词</span></div>
        <div class="sg"><b>${s.reviews||0}</b><span>复习次数</span></div>
        <div class="sg"><b>${s.decks||0}</b><span>课时完成</span></div>
        <div class="sg"><b>${total||0}</b><span>总计练习</span></div>
      </div>
    </header>

    <!-- 连续学习 -->
    <div class="streak-card">
      <div class="st-ic">🔥</div>
      <div class="st-body">
        <div class="st-num">${U.streak.count||0} <span>天连续学习</span></div>
        <div class="st-desc">坚持是最好的学习方式, 已经坚持 ${Math.round(Object.keys(U.streak.days||{}).length)} 天!</div>
      </div>
    </div>

    <!-- 成就 -->
    <section class="section">
      <div class="sec-title"><h3>🏅 我的成就 (${U.badges.length}/${ACHIEVEMENTS.length})</h3></div>
      <div class="badge-grid">
        ${ACHIEVEMENTS.map(a=>{
          const got = U.badges.includes(a.id);
          const [cur, tot] = typeof a.prog === 'function' ? a.prog(U) : [0,1];
          return `<div class="badge-card lg ${got?'on':''}">
            <div class="b-ic">${a.icon}</div>
            <div class="b-name">${esc(a.name)}</div>
            <div class="b-desc">${esc(a.desc)}</div>
            <div class="b-prog">
              <div class="b-bar"><i style="width:${Math.min(100,Math.round(cur/tot*100))}%"></i></div>
              <span>${cur}/${tot}</span>
            </div>
          </div>`;
        }).join('')}
      </div>
    </section>

    <!-- 设置 -->
    <section class="section">
      <div class="sec-title"><h3>⚙️ 设置</h3></div>
      <div class="set-group">
        <button class="set-row" onclick="showGoalModal()">
          <span class="set-ic">🎯</span>
          <div class="set-body"><div class="set-name">每日目标</div><div class="set-sub">当前每天 ${U.dailyGoal} 词</div></div>
          <span class="set-arr">›</span>
        </button>
        <button class="set-row" onclick="showRateModal()">
          <span class="set-ic">🔊</span>
          <div class="set-body"><div class="set-name">朗读语速</div><div class="set-sub">当前 ${U.ttsRate}x (系统发音)</div></div>
          <span class="set-arr">›</span>
        </button>
        <div class="set-row" style="cursor:default">
          <span class="set-ic">🌐</span>
          <div class="set-body"><div class="set-name">网络模式</div><div class="set-sub">${AUD.netMode ? '在线 · CDN音质好,首次缓存后离线可用' : '离线 · 仅系统TTS'}</div></div>
          <span class="dot ${AUD.netMode?'on':''}"></span>
        </div>
        <div class="set-row" style="cursor:default">
          <span class="set-ic">🔈</span>
          <div class="set-body"><div class="set-name">自动朗读</div><div class="set-sub">新词卡进入时自动发音</div></div>
          <label class="switch"><input type="checkbox" ${DB.prefs.autoSpeak?'checked':''} onchange="toggleAutoSpeak(this.checked)"><span class="slider"></span></label>
        </div>
        <button class="set-row" onclick="switchAccount()">
          <span class="set-ic">👥</span>
          <div class="set-body"><div class="set-name">切换 / 管理账号</div><div class="set-sub">当前 ${DB.users.length} 个本地账号</div></div>
          <span class="set-arr">›</span>
        </button>
        <button class="set-row" onclick="exportData()">
          <span class="set-ic">⬆️</span>
          <div class="set-body"><div class="set-name">导出学习数据</div><div class="set-sub">备份为 JSON 文件,可跨设备导入</div></div>
          <span class="set-arr">›</span>
        </button>
        <button class="set-row" onclick="importData()">
          <span class="set-ic">⬇️</span>
          <div class="set-body"><div class="set-name">导入学习数据</div><div class="set-sub">从 JSON 备份中合并恢复</div></div>
          <span class="set-arr">›</span>
        </button>
        <button class="set-row warn" onclick="confirmClear()">
          <span class="set-ic">🧹</span>
          <div class="set-body"><div class="set-name">清空本地记录</div><div class="set-sub">此用户所有 SRS/课时/XP 将清零</div></div>
          <span class="set-arr">›</span>
        </button>
      </div>
    </section>

    <div class="foot-note">语界 LinguaVerse v2.1.0 · 纯本地 · 开源 MIT</div>
    <div style="height:30px"></div>
  </div>`;
}

function toggleAutoSpeak(v){ DB.prefs.autoSpeak = !!v; save(); toast(DB.prefs.autoSpeak?'自动朗读已开启':'自动朗读已关闭','🔈'); }

function toggleUserMenu(e){
  if(e) e.stopPropagation();
  let m = document.getElementById('userMenu');
  if(m){ m.remove(); return; }
  m = document.createElement('div');
  m.id = 'userMenu'; m.className = 'user-menu';
  m.innerHTML = `
    <button onclick="switchAccount(); this.closest('.user-menu').remove();">👥 切换账号</button>
    <button onclick="exportData(); this.closest('.user-menu').remove();">⬆️ 导出备份</button>
    <button onclick="document.getElementById('userMenu').remove(); DB.users=[]; DB.session=null; save(); location.reload();" class="warn">🏳️ 退出登录</button>
  `;
  document.body.appendChild(m);
  const rc = e.currentTarget.getBoundingClientRect();
  m.style.right = (window.innerWidth - rc.right + 10) + 'px';
  m.style.top   = (rc.bottom + 8) + 'px';
  setTimeout(()=>document.addEventListener('click', function h(){ m.remove(); document.removeEventListener('click',h); }), 0);
}

/* ============================================================
   设置弹窗
   ============================================================ */
function showGoalModal(){
  showModal('每日目标', `
    <div class="goal-grid small">
      ${[10,15,20,25,30,40].map(n=>`
        <button class="goal-card ${U.dailyGoal===n?'on':''}" onclick="setGoal(${n}); closeModalMask();">
          <div class="g-num">${n}</div>
          <div class="g-desc">${n} / 天</div>
        </button>`).join('')}
    </div>
  `);
}
function setGoal(n){ U.dailyGoal = +n; save(); toast(`每日目标 ${n} 词`,'🎯'); render(); }

function showRateModal(){
  showModal('朗读语速', `
    <div class="rate-row">
      ${[0.5,0.75,1,1.25,1.5].map(r=>`
        <button class="pill ${U.ttsRate===r?'on':''}" onclick="setRate(${r})">${r}x</button>`).join('')}
    </div>
    <div class="hint">试听:<button class="pill" onclick="speak('Hello, this is a pronunciation test for your dictionary learning.', 'en', ${U.ttsRate||1})">🔊 Test (en)</button></div>
  `);
}
function setRate(r){ U.ttsRate = r; save(); toast(`语速 ${r}x`,'🔊'); render(); }

/* ---------- 通用模态框 ---------- */
function showModal(title, html){
  let mask = $('#modalMask');
  if(!mask){
    mask = document.createElement('div');
    mask.id='modalMask'; mask.className='modal-mask';
    mask.innerHTML = `<div class="modal" role="dialog" aria-modal="true">
        <div class="modal-head">
          <h3 id="modalTitle"></h3>
          <button class="icon-btn" onclick="closeModalMask()">×</button>
        </div>
        <div class="modal-body" id="modalBody"></div>
      </div>`;
    mask.onclick = e => { if(e.target === mask) closeModalMask(); };
    document.body.appendChild(mask);
  }
  $('#modalTitle').textContent = title;
  $('#modalBody').innerHTML = html;
  mask.classList.add('in');
}
function closeModalMask(){ const m = $('#modalMask'); if(m) m.classList.remove('in'); }

/* ============================================================
   本地账号: 切换 / 导入导出 / 清空
   ============================================================ */
function switchAccount(){
  const users = DB.users;
  showModal('切换 / 管理账号', `
    <div class="user-list">
      ${users.map(u=>`
        <button class="user-row ${u.id===U.id?'on':''}" onclick="selectAccount('${u.id}')">
          <span class="ur-av">${u.avatar}</span>
          <div class="ur-body">
            <div class="ur-name">${esc(u.name)}</div>
            <div class="ur-sub">${LANGUAGES[u.lang].flag} ${LANGUAGES[u.lang].name} · Lv.${Math.floor(u.xp/200)+1} · XP ${u.xp}</div>
          </div>
          ${u.id===U.id?'<span class="ur-cur">当前</span>':'<span class="ur-go">›</span>'}
        </button>`).join('')}
    </div>
    <button class="btn btn-ghost btn-lg wide" onclick="closeModalMask(); DB.session=null; U=null; save(); startOnboard();">＋ 创建新账号</button>
  `);
}
function selectAccount(id){
  const u = DB.users.find(x=>x.id===id); if(!u) return;
  DB.session = id; U = u; save(); closeModalMask(); toast(`已切换到 ${u.name}`,'👤'); go('home');
}

function exportData(){
  const data = { users: DB.users, session: DB.session, prefs: DB.prefs,
                 exportedAt: new Date().toISOString(), appVersion:'2.1.0' };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `yujie-export-${today()}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 1000);
  toast('数据已导出 JSON','📦');
}
function importData(){
  const input = document.createElement('input');
  input.type = 'file'; input.accept='application/json';
  input.onchange = () => {
    const f = input.files[0]; if(!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      try{
        const o = JSON.parse(reader.result);
        if(!o.users || !Array.isArray(o.users)) throw new Error('格式错误');
        let merged = 0, added = 0;
        o.users.forEach(nu=>{
          const i = DB.users.findIndex(x=>x.id===nu.id);
          if(i>=0){ if((nu.xp||0) > (DB.users[i].xp||0)){ DB.users[i] = nu; merged++; } }
          else { DB.users.push(nu); added++; }
        });
        save();
        toast(`导入成功 · 新增 ${added} · 合并 ${merged}`,'📥');
        if(!DB.users.find(u=>u.id===DB.session)) DB.session = DB.users[0] && DB.users[0].id;
        U = DB.users.find(u=>u.id===DB.session) || DB.users[0] || null;
        render(); closeModalMask();
      }catch(e){
        toast('导入失败: '+e.message,'❌');
      }
    };
    reader.readAsText(f);
  };
  input.click();
}
function confirmClear(){
  showModal('⚠️ 清空学习记录', `
    <p class="warn-text">本操作会将 <b>${esc(U.name)}</b> 的所有学习数据(SRS记录/课时完成/XP/成就)清零,无法恢复。</p>
    <div class="row-btns">
      <button class="btn btn-ghost btn-lg" onclick="closeModalMask()">取消</button>
      <button class="btn btn-danger btn-lg" onclick="doClear()">确认清空</button>
    </div>
  `);
}
function doClear(){
  U.srs = {}; U.lessons = {}; U.badges = []; U.stats = {decks:0,words:0,reviews:0,grammar:0,listen:0,speak:0};
  U.log = {}; U.xp = 0; U.streak = {count:0, last:'', days:{}};
  save(); closeModalMask(); toast('已清零,重新开始吧','🧹'); render();
}

/* ============================================================
   成就系统
   ============================================================ */
function checkBadges(){
  const before = U.badges.length;
  ACHIEVEMENTS.forEach(a => {
    if(!U.badges.includes(a.id) && typeof a.check === 'function' && a.check(U)){
      U.badges.push(a.id);
      setTimeout(()=>toast(`解锁成就「${a.name}」`, a.icon), U.badges.length*400);
    }
  });
  if(U.badges.length > before) setTimeout(confetti, 500);
  save();
}

/* ---------- 连续打卡 ---------- */
function touchStreak(){
  const t = today();
  const last = U.streak.last;
  const days = U.streak.days || {};
  days[t] = true;
  if(!last){ U.streak.count = 1; }
  else if(last === t){ /* 同一天, 不变 */ }
  else {
    const y = dateKey(-1);
    if(last === y) U.streak.count++;
    else U.streak.count = 1;
  }
  U.streak.last = t;
  U.streak.days = days;
}

/* ============================================================
   学习播放器
   ============================================================ */
let P = null; // player state {id, type, lang, level, queue, idx, flip, newWords, reviews}
function openLesson(lang, level, id){
  // 根据类型分发: vocab 走词卡, 其他走 quiz
  let found = null;
  const units = COURSES[lang] && COURSES[lang][level];
  outer:
  for(const u of units || []){
    for(const l of u.lessons){ if(l.id===id){ found = l; break outer; } }
  }
  if(!found){ toast('课时不存在','❓'); return; }
  if(found.type === 'vocab') startVocabSession(lang, level, found);
  else startQuizSession(lang, level, found);
}
/* --- 词汇播放器: 不背单词式翻卡 --- */
function startVocabSession(lang, level, lesson){
  const words = lessonWords(lesson.id);
  if(!words.length){ toast('这节课暂时没有单词','📭'); return; }
  // 优先学新词 / 到期词
  const newW = [], dueW = [], oldW = [];
  for(const w of words){
    const s = (U.srs[lesson.id]||{})[w.w];
    if(!s || !s.seen) newW.push({lesson:lesson.id, w});
    else if(s.due <= today()) dueW.push({lesson:lesson.id, w});
    else oldW.push({lesson:lesson.id, w});
  }
  const queue = shuffle(newW).concat(shuffle(dueW));
  if(!queue.length){
    showModal('✅ 本课已完成', `
      <div class="done-tile">
        <div class="done-ic">🎉</div>
        <div class="done-title">「${esc(lesson.title)}」没有新词或到期词</div>
        <div class="done-sub">已掌握 ${oldW.length} 个 · 过几天再来复习吧!</div>
        <button class="btn btn-primary btn-lg" onclick="closeModalMask(); go('courses')">返回词书</button>
      </div>`);
    return;
  }
  P = { mode:'vocab', id:lesson.id, lesson, lang, level,
        queue, idx:0, flip:false, newWords:0, reviews:0, total: queue.length };
  renderPlayer();
}
function startReview(){
  const list = dueWords();
  if(!list.length){ toast('没有到期词','📭'); return; }
  P = { mode:'review', id:'review', lesson:null, lang:U.lang, level:U.level,
        queue: shuffle(list), idx:0, flip:false, newWords:0, reviews:0, total: list.length };
  renderPlayer();
}

function renderPlayer(){
  if(!P){ $('#player').hidden = true; return; }
  const player = $('#player'); player.hidden = false;
  const item = P.queue[P.idx];
  if(!item){ finishVocabSession(); return; }
  const lessonId = P.mode==='review' ? item.lesson : P.id;
  const w = (typeof item.w === 'string') ? normWord(lessonId, (CONTENT[lessonId].words.find(x=>x[0]===item.w))) : item.w;
  const isNew = !(U.srs[lessonId] && U.srs[lessonId][w.w] && U.srs[lessonId][w.w].seen);
  const srs = (U.srs[lessonId]||{})[w.w];
  const prog = Math.round((P.idx)/P.total*100);
  const box = srs?srs.box:0;
  player.innerHTML = `
    <div class="player-wrap">
      <div class="pl-top">
        <button class="pl-close" onclick="askClosePlayer()">✕</button>
        <div class="pl-progress"><i style="width:${prog}%"></i></div>
        <div class="pl-count">${P.idx+1}/${P.total}</div>
      </div>
      <div class="pl-title-row">
        <span class="pl-type ${isNew?'new':'due'}">${isNew?'新学':'复习'}</span>
        <span class="pl-course">${P.mode==='review'?'复习 Tab':esc(P.lesson.title)}</span>
        ${srs?`<span class="pl-box">Box ${box} · ${SRS_INTERVALS[Math.min(box,SRS_INTERVALS.length-1)]}天</span>`:''}
      </div>

      <div class="word-card ${P.flip?'flip':''}" id="wordCard"
           oncontextmenu="return false"
           onmousedown="cardMouseDown(event)"
           ontouchstart="cardTouchStart(event)"
           ontouchend="cardTouchEnd(event)">
        <div class="wc-face wc-front">
          <button class="speak-big" onclick="event.stopPropagation(); speakCur(event)">🔊</button>
          <div class="wc-word">${esc(w.w)}</div>
          <div class="wc-phonetic">${esc(w.ph||'')}</div>
          <button class="wc-flip-tip" onclick="flipCard()">点击卡片查看释义 ↓</button>
        </div>
        <div class="wc-face wc-back">
          <div class="wc-word small">${esc(w.w)} <span class="wc-phon small">${esc(w.ph||'')}</span>
            <button class="speak-inline" onclick="event.stopPropagation(); speakCur(event)">🔊</button>
          </div>
          ${w.def?`<div class="wc-def">${esc(w.def)}</div>`:''}
          ${w.root?`<div class="wc-root">🧩 ${esc(w.root)}</div>`:''}
          <div class="wc-ex">
            ${(w.ex||[]).slice(0,3).map((e,i)=>`
              <div class="ex-item">
                ${e.tag?`<span class="ex-tag ${'tag-'+e.tag}">${e.tag}</span>`:''}
                <div class="ex-sent">${esc(e.t||'')}
                  <button class="ex-speak" onclick="event.stopPropagation(); speakEx(${i}, event)">🔊</button>
                </div>
                ${e.m?`<div class="ex-cn">${esc(e.m)}</div>`:''}
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <div class="pl-actions">
        <button class="pl-btn unknown" onclick="gradeWord(false)">
          <span class="pb-ic">✕</span>
          <span class="pb-lb">不认识</span>
          <span class="pb-sub">${SRS_INTERVALS[Math.max(0,box-1)]||1}天后到期</span>
        </button>
        <button class="pl-btn known" onclick="gradeWord(true)">
          <span class="pb-ic">✓</span>
          <span class="pb-lb">认识</span>
          <span class="pb-sub">${SRS_INTERVALS[Math.min(box,SRS_INTERVALS.length-1)]||30}天后到期</span>
        </button>
      </div>
      <div class="pl-sw-hint">← 左滑=不认识 · 右滑=认识 · 点击翻面 · 长按发音</div>
    </div>`;
  // 自动朗读 (正面)
  if(!P.flip && DB.prefs.autoSpeak){
    setTimeout(()=>speak(w.w, P.lang, U.ttsRate, {source:'word'}), 200);
  }
}

/* ------ 词卡事件:点击翻面/滑动评分/长按发音 ------ */
function flipCard(){
  if(!P) return;
  P.flip = !P.flip;
  haptic(P.flip?'medium':'light');
  renderPlayer();
}
function speakCur(e){ if(e) e.stopPropagation();
  const it = P.queue[P.idx]; if(!it) return;
  const w = (typeof it.w==='string')? it.w : it.w.w;
  speak(w, P.lang, U.ttsRate, {source:'word'});
}
function speakEx(i,e){
  if(e) e.stopPropagation();
  const it = P.queue[P.idx]; if(!it) return;
  const lessonId = P.mode==='review'? it.lesson : P.id;
  const w = (typeof it.w==='string') ? normWord(lessonId, CONTENT[lessonId].words.find(x=>x[0]===it.w)) : it.w;
  const ex = w.ex[i]; if(!ex) return;
  speak(ex.t, P.lang, U.ttsRate, {source:'sentence'});
}
/* 左右滑动 */
let _sd = null;
function cardTouchStart(e){
  const t = e.touches[0]; _sd = {x:t.clientX, y:t.clientY, t:Date.now(), hold:null};
  _sd.hold = setTimeout(()=>{ speakCur(e); haptic('medium'); _sd.hold=null; }, 450);
}
function cardTouchEnd(e){
  if(!_sd) return;
  if(_sd.hold){ clearTimeout(_sd.hold); _sd.hold=null; }
  const t = (e.changedTouches && e.changedTouches[0]) || {};
  handleSwipe(t.clientX, t.clientY, Date.now()-_sd.t);
  _sd = null;
}
function cardMouseDown(e){
  _sd = {x:e.clientX, y:e.clientY, t:Date.now(), hold:setTimeout(()=>{speakCur();haptic('medium');_sd.hold=null;},450)};
  const move = ev=>{
    if(_sd && _sd.hold && Math.hypot(ev.clientX-_sd.x,ev.clientY-_sd.y)>8){
      clearTimeout(_sd.hold); _sd.hold=null;
    }
  };
  const up = ev=>{
    document.removeEventListener('mousemove',move);
    document.removeEventListener('mouseup',up);
    if(_sd && _sd.hold){ clearTimeout(_sd.hold); _sd.hold=null; }
    if(!_sd) return;
    const d = Date.now()-_sd.t;
    // 点击 (<120ms, 位移<10px)=翻面
    const dx = ev.clientX-_sd.x, dy = ev.clientY-_sd.y;
    if(dx*dx+dy*dy < 100 && d < 220){ flipCard(); _sd=null; return; }
    handleSwipe(ev.clientX, ev.clientY, d);
    _sd = null;
  };
  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}
function handleSwipe(x, y, dt){
  if(!_sd) return;
  const dx = (x||0) - _sd.x;
  if(Math.abs(dx) < 55 || dt > 900) return;
  haptic(dx<0?'heavy':'medium');
  if(dx < 0) gradeWord(false);  // 左滑 = 不认识
  else      gradeWord(true);   // 右滑 = 认识
}
function bindSwipe(){
  // 绑定其他区域需要时可扩展(当前仅 player 动态绑)
}

/* ------ 认识 / 不认识 分级 ------ */
function gradeWord(known){
  if(!P) return;
  const item = P.queue[P.idx];
  const lessonId = P.mode==='review' ? item.lesson : P.id;
  const word = (typeof item.w==='string') ? item.w : item.w.w;
  if(!U.srs[lessonId]) U.srs[lessonId] = {};
  const s = U.srs[lessonId][word] || {box:0, due:today(), reps:0, seen:false};

  if(known){
    s.box = Math.min(s.box+1, SRS_INTERVALS.length);
    s.due = dateKey(SRS_INTERVALS[Math.min(s.box-1, SRS_INTERVALS.length-1)]);
    if(!s.seen){ s.seen = true; P.newWords++; U.stats.words++; }
    P.reviews++;
    P.idx++;
  } else {
    s.box = Math.max(0, s.box-1);
    s.due = dateKey(SRS_INTERVALS[Math.max(s.box,0)] || 1);
    // 稍后重现
    const reinsert = P.queue[P.idx];
    P.queue.splice(Math.min(P.idx+3, P.queue.length), 0, reinsert);
    P.total = P.queue.length;
    if(!s.seen){ s.seen = true; P.newWords++; U.stats.words++; }
    P.reviews++;
    P.idx++;
  }
  s.reps++;
  U.srs[lessonId][word] = s;
  P.flip = false;

  const lg = todayLog(); lg.words = (lg.words||0) + (known?1:0); lg.review = (lg.review||0) + (known?0:1);
  U.log[today()] = lg;

  if(P.idx >= P.queue.length){ finishVocabSession(); return; }
  save();
  renderPlayer();
}

function finishVocabSession(){
  const xp = Math.round(P.newWords*2.5 + P.reviews*0.8);
  U.xp += xp;
  if(P.mode === 'vocab'){
    U.lessons[P.id] = {done:true, at:Date.now(), xp, score: Math.min(100, Math.round(P.reviews/Math.max(1,P.total)*95 + 5))};
    U.stats.decks++;
  }
  const t = todayLog(); t.xp = (t.xp||0) + xp; U.log[today()] = t;
  touchStreak();
  checkBadges();
  save();
  showModal('🎉 本节完成', `
    <div class="finish-tile">
      <div class="ft-ring">
        <svg viewBox="0 0 120 120">
          <defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#00B578"/><stop offset="100%" stop-color="#2E6BFF"/>
          </linearGradient></defs>
          <circle cx="60" cy="60" r="52" stroke="rgba(0,0,0,.06)" stroke-width="12" fill="none"/>
          <circle cx="60" cy="60" r="52" stroke="url(#gg)" stroke-width="12" fill="none"
                  stroke-linecap="round" stroke-dasharray="${2*Math.PI*52}"
                  stroke-dashoffset="${2*Math.PI*52*(1 - Math.min(1,P.reviews/Math.max(1,P.total)))}"
                  transform="rotate(-90 60 60)"/>
        </svg>
        <div class="ft-c">
          <div class="ft-n">+${xp}</div>
          <div class="ft-t">XP</div>
        </div>
      </div>
      <h2 class="ft-title">${P.mode==='review'?'复习完成!':'课程完成! 🎊'}</h2>
      <div class="ft-stats">
        <div class="ft-s"><b>${P.newWords}</b><span>新学</span></div>
        <div class="ft-s"><b>${P.reviews}</b><span>练习</span></div>
        <div class="ft-s"><b>${Math.round(P.reviews/Math.max(1,P.total)*100)}%</b><span>正确率</span></div>
      </div>
      <div class="row-btns" style="margin-top:20px">
        <button class="btn btn-ghost btn-lg" onclick="closePlayer(); closeModalMask();">返回</button>
        <button class="btn btn-primary btn-lg" onclick="closeModalMask(); go('home');">去首页 →</button>
      </div>
    </div>`);
  P = null;
  $('#player').hidden = true;
}

function askClosePlayer(){
  if(!P){ closePlayer(); return; }
  showModal('退出学习?',`
    <p>当前进度 <b>${P.idx}/${P.total}</b>,未保存,下次打开重新开始。</p>
    <div class="row-btns">
      <button class="btn btn-ghost btn-lg" onclick="closeModalMask()">继续学习</button>
      <button class="btn btn-danger btn-lg" onclick="closeModalMask(); closePlayer();">确认退出</button>
    </div>`);
}
function closePlayer(){ P = null; $('#player').hidden = true; render(); }

/* ============================================================
   语法 / 听力 / 口语 通用 Quiz 播放器
   ============================================================ */
function startQuizSession(lang, level, lesson){
  const content = CONTENT[lesson.id];
  if(!content){ toast('课时内容缺失','❌'); return; }
  const type = lesson.type;
  const t = TYPE_META[type];
  P = { mode:'quiz', id:lesson.id, lesson, lang, level, type,
        content, idx:0, score:0, userAns:[], listeningCount:0, speakingCount:0 };
  if(type==='listening') P.questions = content.dialogs || [];
  else if(type==='speaking') P.questions = content.topics || [];
  else P.questions = content.questions || [];
  if(!P.questions.length){ toast('这节课还在准备中','⏳'); P=null; return; }
  renderQuiz();
}
function renderQuiz(){
  if(!P){ $('#player').hidden = true; return; }
  $('#player').hidden = false;
  const q = P.questions[P.idx];
  const total = P.questions.length;
  const prog = Math.round((P.idx)/total*100);
  let body = '';
  if(P.type==='grammar'){
    body = `
      <div class="q-head">
        <div class="q-num">Q ${P.idx+1} / ${total}</div>
        <div class="q-type-tag">✏️ 语法</div>
      </div>
      <div class="q-stem">${q.q}</div>
      <div class="q-options">
        ${q.o.map((op,i)=>`<button class="q-opt" data-i="${i}" onclick="answerQuiz(${i})">
          <span class="qo-idx">${String.fromCharCode(65+i)}</span>
          <span>${esc(op)}</span>
        </button>`).join('')}
      </div>`;
  } else if(P.type==='listening'){
    body = `
      <div class="q-head">
        <div class="q-num">Q ${P.idx+1} / ${total}</div>
        <div class="q-type-tag">🎧 听力</div>
      </div>
      <div class="listen-card">
        <button class="listen-btn" id="replayListenBtn" onclick="replayListen()">
          <span class="lb-play">▶</span>
          <div class="lb-text">
            <div class="lb-1">点击播放对话</div>
            <div class="lb-2">TTS ${(P.lang==='en'?'English':P.lang==='ja'?'Japanese':'Korean')} · 语速 ${U.ttsRate}x</div>
          </div>
        </button>
      </div>
      <div class="q-stem">${q.q}</div>
      <div class="q-options">
        ${q.o.map((op,i)=>`<button class="q-opt" data-i="${i}" onclick="answerQuiz(${i})">
          <span class="qo-idx">${String.fromCharCode(65+i)}</span><span>${esc(op)}</span>
        </button>`).join('')}
      </div>`;
  } else if(P.type==='speaking'){
    body = `
      <div class="q-head">
        <div class="q-num">Q ${P.idx+1} / ${total}</div>
        <div class="q-type-tag">🎤 口语跟读</div>
      </div>
      <div class="q-stem">话题:<b> ${esc(q.topic||q.t)}</b></div>
      <div class="speak-area">
        <div class="speak-model">
          <div class="sm-label">🗣️ 示范</div>
          <div class="sm-sent">${esc(q.sentence||q.demo||'')}</div>
          <button class="btn btn-ghost btn-sm" onclick="speak(${JSON.stringify(q.sentence||q.demo||'')},'${P.lang}', U.ttsRate)">🔊 听示范</button>
        </div>
        <div class="speak-your">
          <div class="sm-label">🎙️ 你的跟读</div>
          <button class="btn btn-primary rec-btn" id="recBtn" onclick="startRecognize('${P.lang}')">▶ 开始录音</button>
          <div class="rec-result" id="recResult"></div>
          <button class="btn btn-ghost btn-sm" onclick="speakSelf()">🔈 自听</button>
        </div>
        <div class="speak-score" id="speakScore"></div>
      </div>
      <div class="row-btns" style="margin-top:16px">
        <button class="btn btn-ghost btn-lg" onclick="nextQuiz(0)">跳过</button>
        <button class="btn btn-primary btn-lg" onclick="nextQuiz(1)">我已完成 →</button>
      </div>`;
  }
  $('#player').innerHTML = `
    <div class="player-wrap">
      <div class="pl-top">
        <button class="pl-close" onclick="askClosePlayer()">✕</button>
        <div class="pl-progress"><i style="width:${prog}%"></i></div>
        <div class="pl-count">${P.idx+1}/${total}</div>
      </div>
      <div class="pl-title-row">
        <span class="pl-type new">${t.icon} ${t.name}</span>
        <span class="pl-course">${esc(P.lesson.title)} · XP +${P.lesson.xp}</span>
      </div>
      <div class="quiz-body">${body}</div>
    </div>`;
  if(P.type==='listening') setTimeout(()=>replayListen(), 280);
}
function replayListen(){
  if(!P || P.type!=='listening') return;
  const q = P.questions[P.idx];
  const lines = [q.dialog1, q.dialog2, q.dialog3, q.d].filter(Boolean);
  let i=0;
  const next = () => {
    if(i >= lines.length) return;
    speak(lines[i], P.lang, U.ttsRate, {source:'sentence'}).then(()=>{ i++; setTimeout(next, 350); });
  };
  next();
}
function answerQuiz(i){
  if(!P || (P.type!=='grammar' && P.type!=='listening')) return;
  const q = P.questions[P.idx];
  const correct = i === q.a;
  P.userAns.push(i);
  if(correct) P.score++;
  if(P.type==='grammar') U.stats.grammar++;
  if(P.type==='listening') U.stats.listen++;
  // 视觉反馈
  $$('.q-opt').forEach((b,idx)=>{
    b.classList.remove('ok','bad');
    if(idx === q.a) b.classList.add('ok');
    if(idx === i && !correct) b.classList.add('bad');
    b.onclick = null;
  });
  setTimeout(()=>nextQuiz(correct?1:0), 800);
}
/* 语音识别 (口语跟读) */
let _recBuf = '';
function startRecognize(lang){
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  const el = $('#recResult'), btn = $('#recBtn'), score = $('#speakScore');
  el.textContent = ''; score.textContent = ''; _recBuf = '';
  if(!Rec){
    el.innerHTML = `<span class="hint-warn">⚠️ 您的浏览器/设备不支持 Web Speech 识别,请用 Chrome 或开启权限。</span>`;
    return;
  }
  try{
    const r = new Rec();
    r.lang = LANGUAGES[lang].ttsLang;
    r.interimResults = true;
    r.onresult = ev => {
      let s=''; for(let i=ev.resultIndex;i<ev.results.length;i++) s += ev.results[i][0].transcript;
      _recBuf += s; el.textContent = _recBuf;
    };
    r.onerror = e => { el.textContent = '识别失败: '+ (e.error||''); btn.textContent = '▶ 开始录音'; };
    r.onend = () => { btn.textContent = '▶ 开始录音'; scoreSelf(); U.stats.speak++; };
    btn.textContent = '⏺ 录音中 · 点击停止';
    btn.onclick = () => r.stop();
    r.start();
    // 超时自动结束
    setTimeout(()=>{ try{ r.stop(); }catch(e){} }, 8000);
  }catch(e){ el.textContent = '识别异常:'+e.message; }
}
function scoreSelf(){
  if(!P) return;
  const q = P.questions[P.idx];
  const demo = (q.sentence || q.demo || '').toLowerCase().replace(/[^a-z\u4e00-\u9fa5ぁ-ゞァ-ヾ가-힣0-9 ]/g,' ');
  const got = (_recBuf||'').toLowerCase().replace(/[^a-z\u4e00-\u9fa5ぁ-ゞァ-ヾ가-힣0-9 ]/g,' ');
  const A = demo.split(/\s+/).filter(Boolean);
  const B = got.split(/\s+/).filter(Boolean);
  let hit = 0;
  A.forEach(w=>{ if(B.includes(w)) hit++; });
  const acc = A.length ? Math.round(hit/A.length*100) : 0;
  const bar = document.getElementById('speakScore');
  if(!bar) return;
  bar.innerHTML = `
    <div class="score-card">
      <div class="sc-title">跟读评分</div>
      <div class="sc-num">${acc}<span>分</span></div>
      <div class="sc-bar"><i style="width:${acc}%"></i></div>
      <div class="sc-desc">${acc>=85?'⭐️⭐️⭐️⭐️⭐️ 非常棒!':acc>=60?'⭐️⭐️⭐️ 不错,继续加油':'⭐️⭐️ 多听几遍再试试'}</div>
    </div>`;
}
function speakSelf(){
  if(!_recBuf){ toast('先录音吧','🎙️'); return; }
  speak(_recBuf, P.lang, U.ttsRate, {forceNative:false, source:'sentence'});
}
function nextQuiz(point){
  if(!P) return;
  P.idx++;
  P.score += (point||0);
  if(P.idx >= P.questions.length){ finishQuizSession(); return; }
  save(); renderQuiz();
}
function finishQuizSession(){
  const total = P.questions.length;
  const rate = total ? Math.round(P.score/total*100) : 0;
  let xp = Math.max(0, Math.round(P.lesson.xp * (rate/100)));
  U.xp += xp;
  U.lessons[P.id] = {done:true, at:Date.now(), xp, score:rate};
  U.stats.decks++;
  const t = todayLog(); t.xp = (t.xp||0)+xp; U.log[today()] = t;
  touchStreak(); checkBadges(); save();
  showModal('🎉 课时完成', `
    <div class="finish-tile">
      <h2 class="ft-title">${esc(P.lesson.title)} · 得分 ${rate}</h2>
      <div class="ft-stats">
        <div class="ft-s"><b>${P.score}/${total}</b><span>正确率</span></div>
        <div class="ft-s"><b>+${xp}</b><span>XP</span></div>
        <div class="ft-s"><b>${Math.max(0,rate)}</b><span>得分</span></div>
      </div>
      <div class="row-btns" style="margin-top:18px">
        <button class="btn btn-ghost btn-lg" onclick="closeModalMask(); go('courses');">词书</button>
        <button class="btn btn-primary btn-lg" onclick="closeModalMask(); go('home');">首页 →</button>
      </div>
    </div>`);
  P = null; $('#player').hidden = true;
}

/* ============================================================
   每日一句
   ============================================================ */
const DAILY_QUOTES = [
  {en:'The best way to predict the future is to create it.', cn:'预测未来最好的方法就是去创造它。'},
  {en:'A journey of a thousand miles begins with a single step.', cn:'千里之行,始于足下。'},
  {en:'It does not matter how slowly you go as long as you do not stop.', cn:'走得慢也没关系,只要不停步。'},
  {en:'Success is the sum of small efforts repeated day in and day out.', cn:'成功就是日复一日微小努力的总和。'},
  {en:'Learning never exhausts the mind.', cn:'学习永远不会让头脑枯竭。'},
  {en:'Language is the road map of a culture.', cn:'语言是一种文化的地图。'},
  {en:'One language sets you in a corridor for life. Two languages open every door along the way.', cn:'一门语言让你走上人生走廊,两门语言为你打开沿途每一扇门。'},
  {en:'The limits of my language mean the limits of my world.', cn:'我语言的边界就是我世界的边界。'},
  {en:'To have another language is to possess a second soul.', cn:'掌握另一门语言,就是拥有第二个灵魂。'},
];

/* ============================================================
   全局初始化
   ============================================================ */
// 导出调试 API 到 window
window.speak = speak; window.flipCard = flipCard; window.gradeWord = gradeWord;
window.answerQuiz = answerQuiz; window.answerListen = answerQuiz; window.nextQuiz = nextQuiz;
window.startRecognize = startRecognize; window.speakSelf = speakSelf; window.replayListen = replayListen;
window.closePlayer = closePlayer; window.askClosePlayer = askClosePlayer;
window.speakCur = speakCur; window.speakEx = speakEx;
window.setGoal = setGoal; window.setRate = setRate; window.switchAccount = switchAccount;
window.exportData = exportData; window.confirmClear = confirmClear; window.render = render;
window.backToLevels = backToLevels; window.openLesson = openLesson;
window.startReview = startReview; window.go = go; window.openCourse = openCourse;
window.toggleAutoSpeak = toggleAutoSpeak; window.doClear = doClear; window.selectAccount = selectAccount;
window.showModal = showModal; window.closeModalMask = closeModalMask; window.importData = importData;
window.showGoalModal = showGoalModal; window.showRateModal = showRateModal;
window.toggleUserMenu = toggleUserMenu;

document.addEventListener('DOMContentLoaded', () => {
  // 容器
  const phone = document.createElement('div');
  phone.className = 'phone hyper-layout';
  phone.innerHTML = `
    <div class="statusbar"><span class="sb-time" id="sbTime"></span><span class="sb-right">📶 📊 🔋</span></div>
    <main id="app" class="app-scroll" aria-live="polite"></main>
    <div id="player" class="player-wrap-host" hidden></div>
    <div id="toasts" class="toasts"></div>
    <nav id="tabbar" class="tabbar hyper" hidden>
      <button class="tab" data-tab="home">
        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 3.3 3 11h2v9h5v-6h4v6h5v-9h2L12 3.3z"/></svg>
        <span>首页</span>
      </button>
      <button class="tab" data-tab="courses">
        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 4h13a3 3 0 0 1 3 3v13a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V4zm2 2v14h11V6H6zm2 3h8v2H8V9zm0 4h8v2H8v-2z"/></svg>
        <span>词书</span>
      </button>
      <button class="tab" data-tab="review">
        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 3a7 7 0 1 0 6.9 8h-2.4A5 5 0 1 1 17 5v4l5-5-5-5v4zm0 9.5-3.5 3.5 1.4 1.4 1.1-1.1V21h2v-5.2l1.1 1.1 1.4-1.4L17 12.5z"/></svg>
        <span>复习</span>
      </button>
      <button class="tab" data-tab="me">
        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-4 0-8 2-8 6v2h16v-2c0-4-4-6-8-6z"/></svg>
        <span>我的</span>
      </button>
    </nav>
  `;
  document.body.appendChild(phone);
  // 状态栏时间
  const setT = () => { const n = new Date(); const el = document.getElementById('sbTime'); if(el){ el.textContent = String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0'); } };
  setT(); setInterval(setT, 30000);
  // 词书 tab 绑定
  document.addEventListener('click', e => {
    const p = e.target.closest && e.target.closest('.pill[data-lang]');
    if(p && courseLangTab !== undefined){ courseLangTab = p.dataset.lang; render(); }
  }, true);

  // 初始渲染 (若有本地账号 → 首页,否则 → 引导)
  try{
    if(U) render(); else startOnboard();
  }catch(err){
    console.error('[LinguaVerse] init fail:', err);
    try{ startOnboard(); }catch(e2){}
  }

  // Service Worker
  if('serviceWorker' in navigator && location.protocol.startsWith('http')){
    navigator.serviceWorker.register('sw.js').catch(()=>{});
  }
});
